{{- define "edge-component.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "edge-component.fullname" -}}
{{- printf "%s-%s" .Release.Name (include "edge-component.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
